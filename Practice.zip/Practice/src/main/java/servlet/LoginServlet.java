package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Assuming you have a method to validate credentials
        if (validateUser(email, password)) {
            // Redirect to home.jsp upon successful login
            response.sendRedirect("home.jsp");
        } else {
            // If login failed, redirect to login page with an error message
            response.sendRedirect("index.jsp?error=invalid_credentials");
        }
    }

    // Dummy method to validate user (replace with actual DB validation)
    private boolean validateUser(String email, String password) {
        // This is where you would validate the user with a database or other data source.
        // For now, let's assume the correct credentials are:
        String validEmail = "tr@gmail.com";
        String validPassword = "123456";

        return email.equals(validEmail) && password.equals(validPassword);
    }
}
